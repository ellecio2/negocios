<?php

return [

  'key' => env('MERCADOPAGO_KEY', ''),
  'access' => env('MERCADOPAGO_ACCESS', '')


];

